const small: number = 14;
const medium: number = 16;
const large: number = 20;
const xLarge: number = 30;
const xxLarge: number = 35;

export default {
  small,
  medium,
  large,
  xLarge,
  xxLarge,
};
